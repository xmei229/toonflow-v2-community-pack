# 來源與授權

本技能是 Toonflow（https://github.com/HBAI-Ltd/Toonflow-app，MIT License，Copyright (c) 2026 HBAI-Ltd）內建技能 `workflow` 的社群修補版，修改處以 HTML 註解「本地定制」標出。非官方，也非 HBAI-Ltd 發佈。

上游 MIT 授權全文見專案倉庫的 LICENSE。

修補內容：一致性鐵則（含參考的引用寫法）；Wan 3.0 與 H3 的分段提示詞模板（A9.3、A9.4）及其路由例外：使用者明確指定 Wan 或 H3 時，解除 Seedance 路由鎖存，改用新模板。Seedance 2.0 與 2.5 的原有模板與流程未動。
